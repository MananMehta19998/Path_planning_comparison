import numpy as np

def make_sequence(start, velocity, steps=25, accel=(0.0, 0.0), noise=0.03, seed=0):
    rng = np.random.default_rng(seed)
    p = np.array(start, dtype=np.float32)
    v = np.array(velocity, dtype=np.float32)
    a = np.array(accel, dtype=np.float32)
    out = [p.copy()]
    for _ in range(steps-1):
        v = v + a + rng.normal(0, noise, size=2)
        p = p + v + rng.normal(0, noise, size=2)
        out.append(p.copy())
    return np.asarray(out, dtype=np.float32)

def make_training_sequences(n=1200, steps=18, seed=7):
    """
    Synthetic moving-obstacle trajectories for a standalone demo.
    Replace this with your real tracked obstacle histories if available.
    """
    rng = np.random.default_rng(seed)
    seqs = []
    for i in range(n):
        start = rng.uniform(0, 9, size=2)
        velocity = rng.uniform(-0.7, 0.7, size=2)
        accel = rng.normal(0, 0.025, size=2)
        seqs.append(
            make_sequence(
                start,
                velocity,
                steps=steps,
                accel=accel,
                noise=0.04,
                seed=seed+i+1,
            )
        )
    return np.asarray(seqs, dtype=np.float32)
