import argparse
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from bayesian_rnn import BayesianRNN
from config import Config
from synthetic_data import make_training_sequences

def build_dataset(sequences, history_len):
    xs, ys = [], []
    for seq in sequences:
        for t in range(history_len, len(seq)):
            hist = seq[t-history_len:t]
            diffs = np.diff(hist, axis=0, prepend=hist[:1])
            feat = np.concatenate([hist, diffs], axis=1)   # [T,4]
            target_v = seq[t] - seq[t-1]
            xs.append(feat)
            ys.append(target_v)
    return np.asarray(xs, np.float32), np.asarray(ys, np.float32)

def train(epochs=20, batch_size=128, lr=1e-3, out="bayesian_rnn.pt"):
    cfg = Config()
    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)

    seqs = make_training_sequences(seed=cfg.seed)
    X, y = build_dataset(seqs, cfg.history_len)

    ds = TensorDataset(torch.tensor(X), torch.tensor(y))
    dl = DataLoader(ds, batch_size=batch_size, shuffle=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = BayesianRNN(
        hidden_size=cfg.hidden_size,
        num_layers=cfg.num_layers,
        dropout=cfg.dropout,
    ).to(device)

    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = torch.nn.MSELoss()

    for epoch in range(1, epochs+1):
        model.train()
        running = 0.0
        for xb, yb in dl:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            pred = model(xb)
            loss = loss_fn(pred, yb)
            loss.backward()
            opt.step()
            running += loss.item() * len(xb)
        print(f"epoch={epoch:03d} mse={running/len(ds):.6f}")

    torch.save(model.state_dict(), out)
    print("saved:", out)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--out", default="bayesian_rnn.pt")
    args = ap.parse_args()
    train(epochs=args.epochs, out=args.out)
