import argparse
import math
import time
from collections import deque

import matplotlib.pyplot as plt
import numpy as np
import torch

from bayesian_rnn import BayesianRNN
from config import Config
from planners import safety_aware_search
from risk_map import build_spatiotemporal_risk_maps, combine_obstacle_risk_maps
from sde import rollout_sde_from_bayesian_rnn

class MovingObstacle:
    def __init__(self, trajectory):
        self.trajectory = [tuple(map(float, p)) for p in trajectory]
        self.i = 0

    @property
    def pos(self):
        return self.trajectory[min(self.i, len(self.trajectory)-1)]

    def step(self):
        if self.i < len(self.trajectory)-1:
            self.i += 1
        return self.pos

def line_trajectory(start, end, steps=20):
    x0, y0 = start
    x1, y1 = end
    xs = np.linspace(x0, x1, steps)
    ys = np.linspace(y0, y1, steps)
    return list(zip(xs, ys))

def load_model(cfg, checkpoint):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = BayesianRNN(
        hidden_size=cfg.hidden_size,
        num_layers=cfg.num_layers,
        dropout=cfg.dropout,
    ).to(device)
    state = torch.load(checkpoint, map_location=device)
    model.load_state_dict(state)
    return model, device

def ensure_history(hist, pos, length):
    if not hist:
        hist.extend([pos] * length)
    while len(hist) < length:
        hist.appendleft(hist[0])

def current_risk_for_path(path, risk_maps):
    """
    Approximate spatiotemporal path risk:
    path[k] checked against risk map at min(k-1, H-1).
    """
    if len(path) <= 1:
        return 0.0
    vals = []
    H = len(risk_maps)
    for k, (x,y) in enumerate(path[1:], start=1):
        t = min(k-1, H-1)
        vals.append(float(risk_maps[t, y, x]))
    return max(vals) if vals else 0.0

def select_planning_risk(risk_maps):
    """
    Conservative 2-D projection of future time-varying risk.
    For strict time-aware planning, replace with a space-time A*/D* state (x,y,t).
    """
    return np.max(risk_maps, axis=0)

def simulate(checkpoint, planner="euclidean", show=True):
    cfg = Config()
    rng = np.random.default_rng(cfg.seed)

    model, device = load_model(cfg, checkpoint)

    # Earlier crossing experiment:
    # A: (5,9) -> (5,0)
    # B: (0,5) -> (9,5)
    obstacle_A = MovingObstacle(line_trajectory((5,9), (5,0), steps=24))
    obstacle_B = MovingObstacle(line_trajectory((0,5), (9,5), steps=24))
    obstacles = [obstacle_A, obstacle_B]

    histories = [deque(maxlen=cfg.history_len) for _ in obstacles]
    for hist, obs in zip(histories, obstacles):
        hist.extend([obs.pos] * cfg.history_len)

    robot = cfg.start
    executed = [robot]
    planned_path = []
    replans = 0
    total_expanded = 0
    planning_time = 0.0
    min_clearance = float("inf")
    collision = False

    last_combined_risk = None

    for sim_step in range(cfg.max_steps):
        if robot == cfg.goal:
            break

        # Build predictive risk for each moving obstacle
        obs_risks = []
        for j, (hist, obs) in enumerate(zip(histories, obstacles)):
            ensure_history(hist, obs.pos, cfg.history_len)

            trajectories, _ = rollout_sde_from_bayesian_rnn(
                model=model,
                history=list(hist),
                horizon=cfg.horizon,
                dt=cfg.dt,
                mc_samples=cfg.mc_samples,
                rollouts_per_mc=cfg.sde_rollouts_per_mc,
                base_diffusion=cfg.base_diffusion,
                uncertainty_diffusion_gain=cfg.uncertainty_diffusion_gain,
                device=device,
                seed=cfg.seed + 1000*sim_step + j,
            )
            obs_risk = build_spatiotemporal_risk_maps(
                trajectories,
                grid_shape=(cfg.grid_h, cfg.grid_w),
                sigma=cfg.risk_sigma_cells,
            )
            obs_risks.append(obs_risk)

        combined_risk = combine_obstacle_risk_maps(obs_risks)
        risk_2d = select_planning_risk(combined_risk)

        # Event-triggered replanning:
        # replan when no path remains or predicted risk on the current path is high.
        need_replan = not planned_path or robot not in planned_path
        if not need_replan:
            idx = planned_path.index(robot)
            remaining = planned_path[idx:]
            max_path_risk = current_risk_for_path(remaining, combined_risk)
            need_replan = max_path_risk >= cfg.replan_risk_threshold

        if need_replan:
            t0 = time.perf_counter()
            heuristic_kind = None if planner == "dijkstra" else planner
            path, cost, expanded = safety_aware_search(
                robot,
                cfg.goal,
                grid_shape=(cfg.grid_h, cfg.grid_w),
                static_obstacles=cfg.static_obstacles,
                risk_map=risk_2d,
                alpha=cfg.alpha,
                heuristic_kind=heuristic_kind,
                allow_diagonal=(planner != "manhattan"),
                hard_block_threshold=cfg.hard_block_threshold,
            )
            planning_time += time.perf_counter() - t0
            total_expanded += expanded
            replans += 1
            planned_path = path

        if len(planned_path) < 2:
            print("No safe path found.")
            break

        # Advance robot one cell along current planned path
        ridx = planned_path.index(robot)
        if ridx + 1 >= len(planned_path):
            break
        robot = planned_path[ridx+1]
        executed.append(robot)

        # Move obstacles
        for hist, obs in zip(histories, obstacles):
            new_pos = obs.step()
            hist.append(new_pos)

        # Safety metrics
        for obs in obstacles:
            d = math.hypot(robot[0]-obs.pos[0], robot[1]-obs.pos[1])
            min_clearance = min(min_clearance, d)
            if d < 0.55:
                collision = True

        last_combined_risk = combined_risk

    # Euclidean executed length
    path_length = 0.0
    for a,b in zip(executed[:-1], executed[1:]):
        path_length += math.hypot(a[0]-b[0], a[1]-b[1])

    print("\n=== RESULTS ===")
    print("planner:", planner)
    print("reached_goal:", robot == cfg.goal)
    print("collision:", collision)
    print("steps:", len(executed)-1)
    print("path_length:", round(path_length, 3))
    print("replans:", replans)
    print("expanded_nodes:", total_expanded)
    print("planning_time_s:", round(planning_time, 5))
    print("minimum_clearance:", round(min_clearance, 3))

    if show:
        fig, ax = plt.subplots(figsize=(7,7))
        if last_combined_risk is not None:
            risk2d = np.max(last_combined_risk, axis=0)
            ax.imshow(risk2d, origin="lower", extent=(-0.5, 9.5, -0.5, 9.5), alpha=0.55)

        if cfg.static_obstacles:
            sx = [p[0] for p in cfg.static_obstacles]
            sy = [p[1] for p in cfg.static_obstacles]
            ax.scatter(sx, sy, marker="s", s=100, label="static obstacles")

        ex = [p[0] for p in executed]
        ey = [p[1] for p in executed]
        ax.plot(ex, ey, marker="o", label="robot path")

        A = line_trajectory((5,9), (5,0), steps=24)
        B = line_trajectory((0,5), (9,5), steps=24)
        ax.plot([p[0] for p in A], [p[1] for p in A], linestyle="--", label="obstacle A")
        ax.plot([p[0] for p in B], [p[1] for p in B], linestyle="--", label="obstacle B")

        ax.scatter([cfg.start[0]], [cfg.start[1]], s=140, marker="*", label="start")
        ax.scatter([cfg.goal[0]], [cfg.goal[1]], s=140, marker="*", label="goal")
        ax.set_xlim(-0.5, cfg.grid_w-0.5)
        ax.set_ylim(-0.5, cfg.grid_h-0.5)
        ax.set_xticks(range(cfg.grid_w))
        ax.set_yticks(range(cfg.grid_h))
        ax.grid(True)
        ax.legend(loc="upper right")
        ax.set_title("Bayesian RNN + SDE Dynamic Safety Planning")
        plt.tight_layout()
        plt.show()

    return {
        "reached_goal": robot == cfg.goal,
        "collision": collision,
        "path_length": path_length,
        "replans": replans,
        "expanded_nodes": total_expanded,
        "planning_time_s": planning_time,
        "minimum_clearance": min_clearance,
    }

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default="bayesian_rnn.pt")
    ap.add_argument("--planner", choices=["manhattan", "euclidean", "octile", "dijkstra"], default="euclidean")
    ap.add_argument("--no-show", action="store_true")
    args = ap.parse_args()
    simulate(args.checkpoint, planner=args.planner, show=not args.no_show)
