import argparse
import csv
from simulation import simulate

def main(checkpoint):
    planners = ["manhattan", "euclidean", "octile", "dijkstra"]
    rows = []
    for p in planners:
        print("\n\n############################")
        print("RUNNING", p)
        print("############################")
        r = simulate(checkpoint, planner=p, show=False)
        r["planner"] = p
        rows.append(r)

    fields = [
        "planner", "reached_goal", "collision", "path_length",
        "replans", "expanded_nodes", "planning_time_s", "minimum_clearance"
    ]
    with open("planner_comparison.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print("\nsaved: planner_comparison.csv")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default="bayesian_rnn.pt")
    args = ap.parse_args()
    main(args.checkpoint)
