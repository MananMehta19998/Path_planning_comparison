# SDE-Based Bayesian RNN for Dynamic Path Planning

This folder reconstructs the earlier project architecture:

**Observed obstacle histories -> Bayesian RNN / MC Dropout -> SDE rollouts -> probabilistic occupancy risk -> safety-aware dynamic replanning**

## Recovered project details

The earlier work used/considered:

- dynamic path planning on a small grid
- start `(0,0)`, goal `(9,9)`
- crossing dynamic obstacles:
  - obstacle A: `(5,9) -> (5,0)`
  - obstacle B: `(0,5) -> (9,5)`
- Bayesian RNN with Monte Carlo dropout
- stochastic differential equation rollout with Euler-Maruyama
- risk-weighted planning
- safety coefficient `alpha = 10`
- Manhattan / Euclidean / no-heuristic Dijkstra-style comparisons
- replanning count, path cost/length, computation time and safety as metrics
- event-triggered replanning rather than blindly replanning every frame

A separate earlier demo also used static obstacles:
`(1,1), (1,2), (2,4), (2,5), (4,6), (6,3), (6,6)`.

The exact original source files were not recoverable, so this is a faithful runnable reconstruction rather than a byte-for-byte restoration.

---

## 1. Mathematical model

### Bayesian RNN

The predictor sees a recent obstacle history and predicts its next velocity.

Input at each time:
`z_t = [x_t, y_t, v_x,t, v_y,t]`

With dropout active at test time, repeated forward passes give

`v^(m)_{t+1} = f_theta^(m)(z_1:t)`

for `m = 1,...,M`.

The sample mean estimates the expected velocity and the sample covariance estimates epistemic uncertainty.

### SDE

The predicted obstacle evolves according to

`dX_t = mu_t dt + Sigma_t dW_t`

where the Bayesian RNN supplies the drift `mu_t` and diffusion grows with predictive uncertainty.

Euler-Maruyama:

`X_{t+dt} = X_t + mu_t dt + Sigma_t sqrt(dt) epsilon`

with `epsilon ~ N(0,I)`.

The code therefore captures two uncertainty sources:

- MC-dropout spread -> epistemic/model uncertainty
- SDE noise -> process/aleatoric uncertainty

### Risk map

For each time horizon, every Monte Carlo/SDE sample deposits a Gaussian occupancy kernel on the grid.

`R_t(x,y) ~= E[ exp(-||[x,y]-X_t||^2/(2 sigma^2)) ]`

Multiple dynamic obstacles are combined by probabilistic union:

`R_any = 1 - product_i (1 - R_i)`

### Safety-aware path cost

The planner uses

`C(n -> n') = movement_cost + alpha * R(n')`

with default `alpha = 10`.

Very high-risk cells can additionally be treated as hard obstacles.

---

## 2. Install

```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
```

---

## 3. Train the Bayesian RNN

The included trainer generates synthetic obstacle trajectories so the project runs standalone.

```bash
python train_predictor.py --epochs 20 --out bayesian_rnn.pt
```

For your real project, replace `synthetic_data.py` with tracked obstacle-coordinate sequences.

---

## 4. Run one dynamic-planning experiment

Euclidean A*:

```bash
python simulation.py --checkpoint bayesian_rnn.pt --planner euclidean
```

Manhattan:

```bash
python simulation.py --checkpoint bayesian_rnn.pt --planner manhattan
```

Octile:

```bash
python simulation.py --checkpoint bayesian_rnn.pt --planner octile
```

Dijkstra / no heuristic:

```bash
python simulation.py --checkpoint bayesian_rnn.pt --planner dijkstra
```

---

## 5. Compare all planners

```bash
python compare_planners.py --checkpoint bayesian_rnn.pt
```

This writes:

`planner_comparison.csv`

Metrics:

- reached goal
- collision
- executed path length
- number of replans
- expanded nodes
- planning time
- minimum clearance to dynamic obstacles

---

## 6. Files

- `config.py` - experiment settings
- `bayesian_rnn.py` - LSTM + MC-dropout predictor
- `sde.py` - Euler-Maruyama stochastic rollouts
- `risk_map.py` - time-indexed probabilistic risk maps
- `planners.py` - safety-aware A*/Dijkstra
- `synthetic_data.py` - standalone training trajectories
- `train_predictor.py` - RNN training
- `simulation.py` - moving-obstacle simulation + event-triggered replanning
- `compare_planners.py` - benchmark script

---

## 7. About D* / D* Lite

The earlier project discussions included D* variants for dynamic replanning. The exact old D* Lite implementation was not recovered. This reconstruction implements repeated/event-triggered safety-aware A*/Dijkstra, which preserves the uncertainty and risk-planning part of the project but is not mathematically identical to D* Lite.

If an exact D* Lite implementation is required, it should replace the call to `safety_aware_search()` while keeping the Bayesian-RNN/SDE/risk-map pipeline unchanged.
