import numpy as np
from bayesian_rnn import mc_predict_velocity

def euler_maruyama_step(position, drift_velocity, diffusion, dt, rng):
    """
    dX_t = mu_t dt + Sigma_t dW_t

    Euler-Maruyama:
    X_{t+dt} = X_t + mu_t dt + Sigma_t sqrt(dt) epsilon
    """
    epsilon = rng.normal(size=2)
    return (
        np.asarray(position, dtype=np.float32)
        + np.asarray(drift_velocity, dtype=np.float32) * dt
        + np.asarray(diffusion, dtype=np.float32) * np.sqrt(dt) * epsilon
    )

def rollout_sde_from_bayesian_rnn(
    model,
    history,
    horizon,
    dt,
    mc_samples,
    rollouts_per_mc,
    base_diffusion=0.12,
    uncertainty_diffusion_gain=0.55,
    device="cpu",
    seed=0,
):
    """
    Combines:
      1) epistemic uncertainty from MC dropout
      2) aleatoric/process uncertainty through SDE diffusion

    Returns:
      trajectories: [mc_samples * rollouts_per_mc, horizon, 2]
      diagnostics: list of per-horizon dicts
    """
    rng = np.random.default_rng(seed)
    trajectories = []
    diagnostics = []

    # Each MC sample acts as one approximate model draw.
    for mc_idx in range(mc_samples):
        local_history = [tuple(p) for p in history]
        traj_group = [[] for _ in range(rollouts_per_mc)]

        for k in range(horizon):
            vel_samples, vel_mean, vel_cov = mc_predict_velocity(
                model, local_history, mc_samples=mc_samples, device=device
            )

            # epistemic scale from MC prediction spread
            eigvals = np.linalg.eigvalsh(vel_cov)
            epistemic_scale = float(np.sqrt(max(eigvals.max(), 1e-8)))

            # diagonal diffusion; larger model uncertainty => wider SDE rollouts
            sigma = base_diffusion + uncertainty_diffusion_gain * epistemic_scale
            diffusion = np.array([sigma, sigma], dtype=np.float32)

            last = np.asarray(local_history[-1], dtype=np.float32)
            next_positions = []
            for r in range(rollouts_per_mc):
                p = euler_maruyama_step(last, vel_samples[mc_idx], diffusion, dt, rng)
                traj_group[r].append(p.copy())
                next_positions.append(p)

            # propagate the nominal history using mean of the stochastic particles
            nominal_next = np.mean(next_positions, axis=0)
            local_history = (local_history + [tuple(nominal_next)])[-max(2, len(history)):]

            if mc_idx == 0:
                diagnostics.append({
                    "step": k + 1,
                    "velocity_mean": vel_mean.tolist(),
                    "velocity_cov": np.asarray(vel_cov).tolist(),
                    "epistemic_scale": epistemic_scale,
                    "diffusion_sigma": sigma,
                })

        trajectories.extend(traj_group)

    return np.asarray(trajectories, dtype=np.float32), diagnostics
