import torch
import torch.nn as nn
import numpy as np

class BayesianRNN(nn.Module):
    """
    Small LSTM predictor with dropout retained at inference time.
    Input at each time step: [x, y, vx, vy]
    Output: next-step velocity [vx, vy]

    Monte Carlo dropout gives an approximate Bayesian predictive ensemble.
    """
    def __init__(self, input_size=4, hidden_size=64, num_layers=1, dropout=0.25):
        super().__init__()
        self.rnn = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
        )
        self.dropout = nn.Dropout(dropout)
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, 2),
        )

    def forward(self, x):
        out, _ = self.rnn(x)
        h = self.dropout(out[:, -1, :])
        return self.head(h)

def history_to_features(history):
    """
    history: [(x0,y0), ...]
    returns shape [T,4] = x,y,vx,vy
    """
    pts = np.asarray(history, dtype=np.float32)
    if len(pts) < 2:
        vel = np.zeros_like(pts)
    else:
        diffs = np.diff(pts, axis=0, prepend=pts[:1])
        vel = diffs
    return np.concatenate([pts, vel], axis=1)

@torch.no_grad()
def mc_predict_velocity(model, history, mc_samples=40, device="cpu"):
    """
    Returns:
        samples: [M,2]
        mean:    [2]
        cov:     [2,2]
    """
    model = model.to(device)
    # IMPORTANT: train() keeps dropout active for MC-dropout inference.
    model.train()

    feat = history_to_features(history)
    x = torch.tensor(feat, dtype=torch.float32, device=device).unsqueeze(0)

    preds = []
    for _ in range(mc_samples):
        v = model(x).squeeze(0).cpu().numpy()
        preds.append(v)

    samples = np.asarray(preds, dtype=np.float32)
    mean = samples.mean(axis=0)
    cov = np.cov(samples.T) if len(samples) > 1 else np.eye(2) * 1e-6
    return samples, mean, cov
