import numpy as np

def gaussian_risk(grid_shape, center_xy, sigma=1.0):
    """
    center_xy is continuous (x,y). Grid indexing is (row=y, col=x).
    """
    h, w = grid_shape
    x0, y0 = center_xy
    yy, xx = np.mgrid[0:h, 0:w]
    d2 = (xx - x0) ** 2 + (yy - y0) ** 2
    return np.exp(-0.5 * d2 / (sigma ** 2))

def build_spatiotemporal_risk_maps(
    trajectories,
    grid_shape,
    sigma=1.0,
):
    """
    trajectories: [N, H, 2]
    Returns risk_maps: [H, grid_h, grid_w] in [0,1]

    For each horizon time, estimate occupancy risk by averaging Gaussian kernels
    centered at Monte Carlo / SDE samples.
    """
    n, horizon, _ = trajectories.shape
    risk_maps = np.zeros((horizon, *grid_shape), dtype=np.float32)

    for t in range(horizon):
        accum = np.zeros(grid_shape, dtype=np.float64)
        for i in range(n):
            accum += gaussian_risk(grid_shape, trajectories[i, t], sigma=sigma)
        accum /= max(n, 1)
        risk_maps[t] = np.clip(accum, 0.0, 1.0)

    return risk_maps

def combine_obstacle_risk_maps(all_risk_maps):
    """
    Probabilistic union:
       P(any occupied) = 1 - prod_i (1 - P_i)
    """
    if not all_risk_maps:
        raise ValueError("Need at least one risk map.")
    combined = np.ones_like(all_risk_maps[0], dtype=np.float32)
    for r in all_risk_maps:
        combined *= (1.0 - np.clip(r, 0, 1))
    return 1.0 - combined
