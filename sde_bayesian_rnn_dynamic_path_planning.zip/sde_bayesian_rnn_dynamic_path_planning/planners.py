import heapq
import math

MOVES_4 = [(1,0), (-1,0), (0,1), (0,-1)]
MOVES_8 = MOVES_4 + [(1,1), (1,-1), (-1,1), (-1,-1)]

def heuristic(a, b, kind="euclidean"):
    ax, ay = a
    bx, by = b
    dx, dy = abs(ax-bx), abs(ay-by)
    if kind == "manhattan":
        return dx + dy
    if kind == "euclidean":
        return math.hypot(dx, dy)
    if kind == "octile":
        return max(dx, dy) + (math.sqrt(2)-1) * min(dx, dy)
    return 0.0

def neighbors(node, grid_shape, allow_diagonal=True):
    x, y = node
    h, w = grid_shape
    moves = MOVES_8 if allow_diagonal else MOVES_4
    for dx, dy in moves:
        nx, ny = x+dx, y+dy
        if 0 <= nx < w and 0 <= ny < h:
            step_cost = math.sqrt(2) if dx != 0 and dy != 0 else 1.0
            yield (nx, ny), step_cost

def reconstruct(parent, goal):
    if goal not in parent:
        return []
    path = [goal]
    while parent[path[-1]] is not None:
        path.append(parent[path[-1]])
    return path[::-1]

def safety_aware_search(
    start,
    goal,
    grid_shape,
    static_obstacles,
    risk_map=None,
    alpha=10.0,
    heuristic_kind="euclidean",
    allow_diagonal=True,
    hard_block_threshold=0.80,
):
    """
    Set heuristic_kind=None or "none" for Dijkstra.
    Cost:
       movement_cost + alpha * risk(cell)
    """
    static_obstacles = set(static_obstacles)
    pq = [(0.0, start)]
    g = {start: 0.0}
    parent = {start: None}
    visited = 0

    while pq:
        fcur, cur = heapq.heappop(pq)
        visited += 1
        if cur == goal:
            return reconstruct(parent, goal), g[cur], visited

        for nxt, move_cost in neighbors(cur, grid_shape, allow_diagonal):
            if nxt in static_obstacles:
                continue

            x, y = nxt
            risk = float(risk_map[y, x]) if risk_map is not None else 0.0
            if risk >= hard_block_threshold:
                continue

            tentative = g[cur] + move_cost + alpha * risk
            if tentative < g.get(nxt, float("inf")):
                g[nxt] = tentative
                parent[nxt] = cur
                h = 0.0 if heuristic_kind in (None, "none", "dijkstra") else heuristic(nxt, goal, heuristic_kind)
                heapq.heappush(pq, (tentative + h, nxt))

    return [], float("inf"), visited
