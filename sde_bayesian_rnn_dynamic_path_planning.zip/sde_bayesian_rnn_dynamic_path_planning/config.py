from dataclasses import dataclass

@dataclass
class Config:
    # Environment
    grid_h: int = 10
    grid_w: int = 10
    start: tuple = (0, 0)
    goal: tuple = (9, 9)

    # Static obstacles from the earlier dynamic-planning demo
    static_obstacles: tuple = (
        (1, 1), (1, 2), (2, 4), (2, 5),
        (4, 6), (6, 3), (6, 6)
    )

    # Prediction / simulation
    history_len: int = 6
    horizon: int = 8
    dt: float = 1.0
    mc_samples: int = 40
    sde_rollouts_per_mc: int = 15

    # Risk construction
    risk_sigma_cells: float = 1.0
    alpha: float = 10.0
    hard_block_threshold: float = 0.80

    # Bayesian RNN
    hidden_size: int = 64
    num_layers: int = 1
    dropout: float = 0.25

    # SDE diffusion
    base_diffusion: float = 0.12
    uncertainty_diffusion_gain: float = 0.55

    # Runtime
    max_steps: int = 40
    replan_risk_threshold: float = 0.35
    seed: int = 7
