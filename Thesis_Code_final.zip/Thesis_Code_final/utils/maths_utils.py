
import cv2
import numpy as np

# -------------------------------
# Image Processing Utilities
# -------------------------------

def to_grayscale(img):
    """Convert BGR image to grayscale."""
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def apply_canny(img, low_thresh=50, high_thresh=150):
    """Apply Canny edge detection."""
    return cv2.Canny(img, low_thresh, high_thresh)

def apply_hough_lines(img, rho=1, theta=np.pi/180, threshold=50):
    """Apply Hough Line Transform to detect straight lines."""
    lines = cv2.HoughLinesP(img, rho, theta, threshold, minLineLength=20, maxLineGap=5)
    return lines

# -------------------------------
# Geometry and Visualization
# -------------------------------

def draw_path_on_map(map_img, path, color=(0, 255, 0), thickness=2):
    """Draws a list of path points on a map image."""
    for i in range(len(path)-1):
        cv2.line(map_img, path[i], path[i+1], color, thickness)
    return map_img

def pixel_to_world(x, y, H):
    """Convert pixel coordinates to world coordinates using homography matrix."""
    pt = np.array([x, y, 1]).reshape(3, 1)
    world_pt = np.dot(H, pt)
    world_pt /= world_pt[2][0]
    return (world_pt[0][0], world_pt[1][0])

# -------------------------------
# Math and General Utilities
# -------------------------------

def clamp(value, min_val, max_val):
    """Clamp a value between min and max."""
    return max(min_val, min(value, max_val))

def angle_diff(a, b):
    """Compute the smallest difference between two angles in radians."""
    d = a - b
    return (d + np.pi) % (2 * np.pi) - np.pi

def normalize_angle(theta):
    """Normalize angle to the range [-pi, pi]."""
    return (theta + np.pi) % (2 * np.pi) - np.pi
