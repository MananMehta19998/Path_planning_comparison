import time
from planning.astar_manhattan import astar_manhattan
from planning.astar_euclidean import astar_euclidean
from planning.dijkstra import dijkstra

graph = {
    (0,0): [((0,1), 1), ((1,0), 1)],
    (0,1): [((0,0), 1), ((1,1), 1)],
    (1,0): [((0,0), 1), ((1,1), 1)],
    (1,1): [((1,0), 1), ((0,1), 1)]
}
start = (0, 0)
goal = (1, 1)

def benchmark(method, func):
    start_time = time.time()
    path = func(graph, start, goal)
    duration = time.time() - start_time
    print(f"{method} took {duration:.6f} seconds.")
    return path

if __name__ == "__main__":
    benchmark("Dijkstra", lambda g, s, g2: dijkstra(g, s))
    benchmark("A* Manhattan", astar_manhattan)
    benchmark("A* Euclidean", astar_euclidean)
