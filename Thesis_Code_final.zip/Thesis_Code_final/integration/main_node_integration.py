#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import String, Float32
from duckietown_msgs.msg import Twist2DStamped

from perception.perception_pipeline import PerceptionPipeline
from planning.dijkstra_planner import DijkstraPlanner
from planning.astar_planner import AStarPlanner
from control.fsm import FSM
from utils.map_loader import MapLoader

class MainNode:
    def __init__(self):
        rospy.init_node('main_node')

        # Initialize modules
        self.map_loader = MapLoader()
        self.perception = PerceptionPipeline()

        self.planner_type = rospy.get_param("~planner", "dijkstra")
        if self.planner_type == "dijkstra":
            self.planner = DijkstraPlanner(self.map_loader.map)
        elif self.planner_type == "astar_manhattan":
            self.planner = AStarPlanner(self.map_loader.map, heuristic="manhattan")
        elif self.planner_type == "astar_euclidean":
            self.planner = AStarPlanner(self.map_loader.map, heuristic="euclidean")
        else:
            rospy.logerr("Invalid planner type specified!")
            exit(1)

        self.fsm = FSM()

        self.motor_pub = rospy.Publisher("/duckiebot/wheels_driver_node/car_cmd", Twist2DStamped, queue_size=10)
        rospy.Subscriber("/duckiebot/camera_node/image/raw", Image, self.camera_callback)

        rospy.loginfo("Main node initialized with %s planner", self.planner_type)

    def camera_callback(self, msg):
        # Step 1: Perception
        perception_data = self.perception.process_image(msg)

        # Step 2: Plan path
        start, goal = perception_data["start"], perception_data["goal"]
        path = self.planner.plan(start, goal)

        # Step 3: FSM + Decision Tree
        current_state = self.fsm.update(perception_data)


        # Step 6: Publish to motor
        twist = Twist2DStamped()
        twist.v = stable_output["velocity"]
        twist.omega = stable_output["omega"]
        self.motor_pub.publish(twist)

if __name__ == '__main__':
    try:
        node = MainNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass