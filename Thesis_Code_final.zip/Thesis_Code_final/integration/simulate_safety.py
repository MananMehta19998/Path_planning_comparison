import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import distance_transform_edt
import time
import tracemalloc

from perception.canny_hough import detect_edges_and_lines
from perception.hu_moments import compute_hu_moments
from planning.dijkstra_safety import dijkstra_safety
from planning.astar_euclidean_safety import astar_euclidean_safety
from planning.astar_manhattan_safety import astar_manhattan_safety
from control.fsm_controller import FSMController

def compute_safety_cost_map(graph, obstacles, grid_size=(11, 11), obstacle_cost=1.0, alpha=10.0):
    """
    Returns a 2D safety cost map where higher cost means closer to obstacle.
    This penalizes risky areas for safety-first planning.
    """
    rows, cols = grid_size
    cost_map = np.ones((rows, cols), dtype=float)

    # Mark obstacle cells with zero cost
    for (x, y) in obstacles:
        if 0 <= x < rows and 0 <= y < cols:
            cost_map[y, x] = 0  # Note: imshow uses (row, col) = (y, x)

    # Compute Euclidean distance transform from obstacles
    dist_map = distance_transform_edt(cost_map)

    # Convert distance to inverse cost: closer = higher penalty
    with np.errstate(divide='ignore'):
        safety_cost_map = obstacle_cost * np.exp(-dist_map / alpha)

    return safety_cost_map

def simulate(image_path, graph_4, graph_8, start, goal):
    fsm = FSMController()
    fsm.transition('start')

    image = cv2.imread(image_path)
    edges, lines = detect_edges_and_lines(image)
    hu = compute_hu_moments(image)

    fsm.transition('perception_ready')
    fsm.transition('path_ready')

    obstacles =  {(1,1), (1,2), (1,2), (2,4), (2,5), (4,6), (6,3), (6,6)}
    for obs in obstacles:
        graph_4.pop(obs, None)
        graph_8.pop(obs, None)
    for graph in (graph_4, graph_8):
        for node in graph:
            graph[node] = [nbr for nbr in graph[node] if nbr[0] not in obstacles] 
    safety_cost_map_4 = compute_safety_cost_map(graph_4, obstacles)
    safety_cost_map_8 = compute_safety_cost_map(graph_8, obstacles) 
    
    log_lines = ["\nSimulation Log - Safety First"]

    # A* Euclidean Safety
    tracemalloc.start()
    start_time = time.perf_counter()
    path_astar_euclidean_safety, visited_euclidean_safety = astar_euclidean_safety(
    graph_8, start, goal, safety_cost_map_8, alpha=10.0)
    end_time = time.perf_counter()
    current, _ = tracemalloc.get_traced_memory()
    log_lines.append(f"Planner: A* Euclidean (Safety-First)")
    log_lines.append(f"Runtime: {end_time - start_time:.6f} sec")
    log_lines.append(f"Memory Usage: {current / 1024:.2f} KB")
    log_lines.append("")
    tracemalloc.stop()

    # A* Manhattan Safety
    tracemalloc.start()
    start_time = time.perf_counter()
    path_astar_manhattan_safety, visited_manhattan_safety = astar_manhattan_safety(
    graph_4, start, goal, safety_cost_map_4, alpha=10.0)
    end_time = time.perf_counter()
    current, _ = tracemalloc.get_traced_memory()
    log_lines.append(f"Planner: A* Manhattan (Safety-First)")
    log_lines.append(f"Runtime: {end_time - start_time:.6f} sec")
    log_lines.append(f"Memory Usage: {current / 1024:.2f} KB")
    log_lines.append("")
    tracemalloc.stop()

    # Dijkstra Safety
    tracemalloc.start()
    start_time = time.perf_counter()
    path_dijkstra_safety, visited_dijkstra_safety = dijkstra_safety(
    graph_8, start, goal, safety_cost_map_8, alpha=10.0)
    end_time = time.perf_counter()
    current, _ = tracemalloc.get_traced_memory()
    log_lines.append(f"Planner: Dijkstra (Safety-First)")
    log_lines.append(f"Runtime: {end_time - start_time:.6f} sec")
    log_lines.append(f"Memory Usage: {current / 1024:.2f} KB")
    log_lines.append("")
    tracemalloc.stop()


    
    print("A* Euclidean Path(Safety-First):", path_astar_euclidean_safety)
    print("A* Manhattan Path(Safety-First):", path_astar_manhattan_safety)
    print("Dijkstra Path(Safety-First):", path_dijkstra_safety)
    
    fsm.transition('goal_reached')
    print("Simulation finished. Final FSM State:", fsm.state)
    #Save log file
    with open("simulation_log_safety.txt", "w") as f:
        f.write("\n".join(log_lines))
    path_dict = {"Dijkstra": path_dijkstra_safety,
                 "A* Manhattan": path_astar_manhattan_safety,
                 "A* Euclidean": path_astar_euclidean_safety
    }
    visited_dict = {"Dijkstra": visited_dijkstra_safety,
                    "A* Manhattan": visited_manhattan_safety,
                    "A* Euclidean": visited_euclidean_safety
    }

    plot_paths(path_dict, obstacles, start=start, goal=goal)
    plot_visited(visited_dict, obstacles, start, goal)
    plot_heatmap((10,10), obstacles, path_dict, start=start, goal=goal)

def generate_graph_4_connected(rows, cols):
    graph = {}
    for i in range(rows):
        for j in range(cols):
            neighbors = []
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ni, nj = i + dx, j + dy
                if 0 <= ni < rows and 0 <= nj < cols:
                    neighbors.append(((ni, nj), 1))
            graph[(i, j)] = neighbors
    return graph

def generate_graph_8_connected(rows, cols):
    graph = {}
    for i in range(rows):
        for j in range(cols):
            neighbors = []
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    if dx == 0 and dy == 0:
                        continue
                    ni, nj = i + dx, j + dy
                    if 0 <= ni < rows and 0 <= nj < cols:
                        neighbors.append(((ni, nj), 1))
            graph[(i, j)] = neighbors
    return graph

def plot_paths(path_dict, obstacles=None, start=(0, 0), goal=(9, 9), grid_size=(10, 10)):
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    planner_info = {
        "Dijkstra": {"color": "green", "title": "Dijkstra (Safety-First)"},
        "A* Manhattan": {"color": "orange", "title": "A* Manhattan (Safety-First)"},
        "A* Euclidean": {"color": "blue", "title": "A* Euclidean (Safety-First)"}
    }

    for idx, (planner, path) in enumerate(path_dict.items()):
        ax = axes[idx]
        info = planner_info.get(planner, {"color": "gray", "title": planner})

        for (ox, oy) in obstacles:
            ax.add_patch(plt.Rectangle((ox - 0.5, oy - 0.5), 1, 1, color='black'))

        if path:
            x, y = zip(*path)
            ax.plot(x, y, marker='o', color=info["color"], linewidth=2)
        ax.plot(start[0], start[1], marker='x', color='purple', markersize=10)
        ax.plot(goal[0], goal[1], marker='x', color='cyan', markersize=10)

        ax.set_xlim(-0.5, grid_size[0] - 0.5)
        ax.set_ylim(-0.5, grid_size[1] - 0.5)
        ax.set_xticks(range(grid_size[0]))
        ax.set_yticks(range(grid_size[1]))
        ax.set_aspect('equal')
        ax.grid(True)
        ax.set_title(info["title"], fontsize=10)

    plt.tight_layout()
    plt.savefig("sim_paths_safety.png", bbox_inches='tight')
    plt.show()

def plot_visited(visited_dict, obstacles, start, goal):
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 3, figsize=(16, 6)) # 3 side-by-side

    planner_info = {
        "Dijkstra": {"color": "green", "title": "Dijkstra Search Tree (Safety-First)"},
        "A* Manhattan": {"color": "orange", "title": "A* Manhattan Search Tree (Safety-First)"},
        "A* Euclidean": {"color": "blue", "title": "A* Euclidean Search Tree (Safety-First)"}
    }

    for idx, (name, visited) in enumerate(visited_dict.items()):
        ax = axes[idx]
        info = planner_info.get(name, {"color": "gray", "title": name})
        if not visited:
            continue
        x = [pt[0] for pt in visited]
        y = [pt[1] for pt in visited]
        ax.scatter(x, y, color=info["color"], alpha=0.4, label=name)

        # Plot obstacles
        for (ox, oy) in obstacles:
            ax.add_patch(plt.Rectangle((ox - 0.5, oy - 0.5), 1, 1, color='black'))

        # Start and goal
        ax.plot(start[0], start[1], marker='x', color='purple')
        ax.plot(goal[0], goal[1], marker='x', color='cyan')

        ax.set_xlim(-0.5, 9.5)
        ax.set_ylim(-0.5, 9.5)
        ax.set_xticks(range(10))
        ax.set_yticks(range(10))
        ax.set_aspect('equal')
        ax.set_title(info["title"])
        ax.grid(True)

    plt.tight_layout()
    plt.savefig("sim_search_tree_safety.png", bbox_inches='tight')

def plot_heatmap(grid_size, obstacles, path_dict, start, goal, threshold=2):
    import matplotlib.pyplot as plt
    import numpy as np
    from scipy.ndimage import distance_transform_edt

    grid = np.ones(grid_size)
    for x, y in obstacles:
        grid[y, x] = 0 # Note: y first because of imshow row-col

    dist_map = distance_transform_edt(grid)
    dist_map[grid == 0] = 0 # Mask obstacles
    dist_map = np.clip(dist_map, 0, threshold) / threshold # Normalize [0,1]

    fig, axes = plt.subplots(1, 3, figsize=(14, 5))
    planners = list(path_dict.keys())
    colors = {'Dijkstra': 'green', 'A* Manhattan': 'orange', 'A* Euclidean': 'blue'}

    for idx, planner in enumerate(planners):
        ax = axes[idx]
        ax.imshow(1 - dist_map, cmap='Reds', origin='lower') # Dark red = close to obstacle

        # Obstacles in dark gray
        for (ox, oy) in obstacles:
            ax.add_patch(plt.Rectangle((ox - 0.5, oy - 0.5), 1, 1, color='dimgray'))

        # Path line
        path = path_dict[planner]
        if path:
            x, y = zip(*path)
            ax.plot(x, y, marker='o', color=colors.get(planner, 'black'), linewidth=2)

        # Start and goal markers
        ax.plot(start[0], start[1], marker='o', color='purple', markersize=6)
        ax.plot(goal[0], goal[1], marker='o', color='cyan', markersize=6)

        ax.set_title(f"{planner} (Safetyty-First)")
        ax.set_xticks(range(grid_size[1]))
        ax.set_yticks(range(grid_size[0]))
        ax.set_aspect('equal')
        ax.grid(True)
        ax.set_xlim(-0.5, grid_size[1] - 0.5)
        ax.set_ylim(-0.5, grid_size[0] - 0.5)

    plt.tight_layout()
    plt.savefig("sim_heatmap_safety.png", bbox_inches='tight')
    plt.close()


if __name__ == "__main__":
    image_path = "dataset/lane_line.jpg"
    graph_4 = generate_graph_4_connected(10, 10)
    graph_8 = generate_graph_8_connected(10, 10)
    start = (0,0)
    goal = (9, 9)

    simulate(image_path, graph_4, graph_8, start, goal)



    

