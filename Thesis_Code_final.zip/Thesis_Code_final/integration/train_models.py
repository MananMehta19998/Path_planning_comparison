import numpy as np
from classification.svm_classifier import train_svm
from control.decision_tree import train_decision_tree

# Example data for SVM
features = np.random.rand(10, 7)  # 7 Hu moments
labels = ['safe', 'obstacle'] * 5
train_svm(features, labels)

# Example data for Decision Tree
X = np.random.rand(10, 5)  # feature vectors
y = ['forward', 'left', 'right', 'stop', 'forward'] * 2
train_decision_tree(X, y)
