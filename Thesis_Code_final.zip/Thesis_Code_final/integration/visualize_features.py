import cv2
import os
from perception.canny_hough import detect_edges_and_lines
from perception.hu_moments import compute_hu_moments

def visualize_features(image_path):
    image = cv2.imread(image_path)
    edges, lines = detect_edges_and_lines(image)

    if lines is not None:
        for line in lines:
            x1,y1,x2,y2 = line[0]
            cv2.line(image, (x1,y1), (x2,y2), (0,255,0), 1)

    cv2.imshow("Detected Features", image)
    cv2.imshow("Edges", edges)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    folder = 'dataset'
    for img_name in ['lane_line.jpg', 'square_object.jpg', 'circular_object.jpg']:
        print(f"Processing {img_name}...")
        visualize_features(os.path.join(folder, img_name))
