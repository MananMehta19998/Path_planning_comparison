import heapq

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def astar_manhattan(graph, start, goal):
    queue = [(0, start)]
    came_from = {start: None}
    cost_so_far = {start: 0}
    visited = set()

    while queue:
        _, current = heapq.heappop(queue)
        if current in visited:
            continue
        visited.add(current)
        
        if current == goal:
            break

        for neighbor, cost in graph[current]:
            new_cost = cost_so_far[current] + cost
            if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                cost_so_far[neighbor] = new_cost
                priority = new_cost + manhattan(neighbor, goal) # f(n) = g(n) + h(n)
                heapq.heappush(queue, (priority, neighbor))
                came_from[neighbor] = current

    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = came_from.get(node)
    path.reverse()
   
    return path, visited
