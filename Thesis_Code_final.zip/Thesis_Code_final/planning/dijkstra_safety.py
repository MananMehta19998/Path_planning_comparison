import heapq

def dijkstra_safety(graph, start, goal, safety_cost_map, alpha):
    dist = {node: float('inf') for node in graph}
    dist[start] = 0
    parent = {start: None}
    visited = set()
    queue = [(0, start)]

    while queue:
        current_dist, current_node = heapq.heappop(queue)

        if current_node in visited:
            continue
        if current_node == goal:
            break

        visited.add(current_node)

        for neighbor, weight in graph[current_node]:
            # Get safety penalty with bounds check
            if (0 <= neighbor[0] < safety_cost_map.shape[0]) and (0 <= neighbor[1] < safety_cost_map.shape[1]):
                safety_penalty = safety_cost_map[neighbor[0], neighbor[1]]
            else:
                safety_penalty = 0

            distance = current_dist + weight + (alpha * safety_penalty) #f(n) = g(n) + p(n)

            if distance < dist[neighbor]:
                dist[neighbor] = distance
                parent[neighbor] = current_node
                heapq.heappush(queue, (distance, neighbor))

    # Reconstruct path
    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = parent.get(node)
    path.reverse()

    return path, visited
