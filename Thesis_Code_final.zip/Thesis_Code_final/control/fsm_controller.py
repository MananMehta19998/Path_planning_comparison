class FSMController:
    def __init__(self):
        self.state = 'Idle'

    def transition(self, event):
        transitions = {
            'Idle': {'start': 'Perceive Environment'},
            'Perceive Environment': {'perception_ready': 'Plan Path'},
            'Plan Path': {'path_ready': 'Navigate'},
            'Navigate': {'obstacle_detected': 'Avoid Obstacle', 'goal_reached': 'Goal Reached'},
            'Avoid Obstacle': {'cleared': 'Navigate'},
        }
        if event in transitions.get(self.state, {}):
            self.state = transitions[self.state][event]
        return self.state
