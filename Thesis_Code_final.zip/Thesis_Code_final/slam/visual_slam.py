#!/usr/bin/env python3

import rospy
import numpy as np
import cv2
from nav_msgs.msg import OccupancyGrid, Odometry
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class VisualSLAMNode:
    def __init__(self):
        rospy.init_node('visual_slam_node')
        self.bridge = CvBridge()

        # Parameters
        self.map_size = 200  # 200x200 grid
        self.resolution = 0.05  # meters per cell
        self.map = np.zeros((self.map_size, self.map_size), dtype=np.int8)  # -1: unknown, 0: free, 100: occupied

        # Robot pose (initially at center of map)
        self.pose = [self.map_size // 2, self.map_size // 2]

        # Publishers & Subscribers
        self.map_pub = rospy.Publisher("/visual_slam/map", OccupancyGrid, queue_size=1, latch=True)
        self.pose_pub = rospy.Publisher("/visual_slam/pose", PoseStamped, queue_size=1)
        rospy.Subscriber("/perception/edges", Image, self.image_callback)

        rospy.loginfo("Visual SLAM Node Initialized")
        rospy.spin()

    def image_callback(self, msg):
        # Convert ROS Image to OpenCV
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="mono8")
        edges = cv2.Canny(frame, 50, 150)

        # Extract features and update pose (simplified visual odometry)
        movement = self.estimate_motion(edges)
        self.update_pose(movement)

        # Mark current cell as visited
        x, y = self.pose
        self.map[y, x] = 0  # Free

        # Update map based on edge data (basic example)
        self.update_map_from_edges(edges)

        # Publish map and pose
        self.publish_map()
        self.publish_pose()

    def estimate_motion(self, edges):
        # Placeholder: Simulate forward motion based on edge density
        density = np.mean(edges)
        dx = 1 if density > 10 else 0
        dy = 0
        return (dx, dy)

    def update_pose(self, movement):
        dx, dy = movement
        self.pose[0] = max(0, min(self.map_size - 1, self.pose[0] + dx))
        self.pose[1] = max(0, min(self.map_size - 1, self.pose[1] + dy))

    def update_map_from_edges(self, edges):
        # Threshold edges and mark as obstacles in map
        obstacle_indices = np.argwhere(edges > 100)
        for y, x in obstacle_indices:
            map_x = self.pose[0] + (x - edges.shape[1] // 2) // 10
            map_y = self.pose[1] + (y - edges.shape[0] // 2) // 10
            if 0 <= map_x < self.map_size and 0 <= map_y < self.map_size:
                self.map[map_y, map_x] = 100  # Occupied

    def publish_map(self):
        grid = OccupancyGrid()
        grid.header.stamp = rospy.Time.now()
        grid.header.frame_id = "map"
        grid.info.resolution = self.resolution
        grid.info.width = self.map_size
        grid.info.height = self.map_size
        grid.info.origin.position.x = -self.map_size // 2 * self.resolution
        grid.info.origin.position.y = -self.map_size // 2 * self.resolution
        grid.info.origin.orientation.w = 1.0
        grid.data = self.map.flatten().tolist()
        self.map_pub.publish(grid)

    def publish_pose(self):
        pose = PoseStamped()
        pose.header.stamp = rospy.Time.now()
        pose.header.frame_id = "map"
        pose.pose.position.x = self.pose[0] * self.resolution
        pose.pose.position.y = self.pose[1] * self.resolution
        pose.pose.orientation.w = 1.0
        self.pose_pub.publish(pose)

if __name__ == "__main__":
    try:
        VisualSLAMNode()
    except rospy.ROSInterruptException:
        pass
