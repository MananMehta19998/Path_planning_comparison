#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from planning.dijkstra import dijkstra
from planning.astar_manhattan import astar_manhattan
from planning.astar_euclidean import astar_euclidean

graph = {
    (0,0): [((0,1), 1), ((1,0), 1)],
    (0,1): [((0,0), 1), ((1,1), 1)],
    (1,0): [((0,0), 1), ((1,1), 1)],
    (1,1): [((1,0), 1), ((0,1), 1)]
}
start = (0,0)
goal = (1,1)

class PlannerNode:
    def __init__(self):
        self.pub = rospy.Publisher("/planned_path", String, queue_size=10)
        rospy.Timer(rospy.Duration(5.0), self.plan_path)

    def plan_path(self, event):
        heuristic = rospy.get_param("/planner/heuristic", "manhattan")
        if heuristic == "dijkstra":
            distances = dijkstra(graph, start)
            path = str(distances)
        elif heuristic == "euclidean":
            came_from, _ = astar_euclidean(graph, start, goal)
            path = self.reconstruct_path(came_from, goal)
        else:
            came_from, _ = astar_manhattan(graph, start, goal)
            path = self.reconstruct_path(came_from, goal)
        self.pub.publish(str(path))
        rospy.loginfo(f"Published path with {heuristic}: {path}")

    def reconstruct_path(self, came_from, goal):
        path = []
        current = goal
        while current is not None:
            path.insert(0, current)
            current = came_from.get(current)
        return path

if __name__ == "__main__":
    rospy.init_node("planner_node", anonymous=True)
    planner = PlannerNode()
    rospy.spin()
