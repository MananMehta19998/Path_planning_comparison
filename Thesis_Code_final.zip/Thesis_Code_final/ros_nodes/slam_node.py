import rospy
from std_msgs.msg import String

def slam():
    rospy.init_node('slam_node')
    rospy.Subscriber('/svm/class_output', String, lambda msg: rospy.loginfo("SLAM Running"))
    rospy.spin()

if __name__ == '__main__':
    slam()