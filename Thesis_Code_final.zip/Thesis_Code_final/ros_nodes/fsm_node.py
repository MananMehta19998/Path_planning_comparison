
#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import joblib
import numpy as np
from fsm_controller import FSMController

class FSMNode:
    def __init__(self):
        rospy.init_node('fsm_node')
        self.fsm = FSMController()
        self.model = joblib.load('/path/to/svm_multi_class_model.pkl')  # Update path if needed
        self.state_pub = rospy.Publisher('/fsm/state', String, queue_size=10)
        rospy.Subscriber('/perception/hu_moments', String, self.callback)
        rospy.loginfo("FSM Node with SVM routing initialized.")

    def callback(self, msg):
        # Parse Hu moment input from perception node
        try:
            hu = np.array(eval(msg.data)).reshape(1, -1)
            predicted_class = self.model.predict(hu)[0]
        except Exception as e:
            rospy.logwarn(f"Error in prediction: {e}")
            predicted_class = 4  # Unknown class

        # FSM Routing Logic based on SVM class
        self.fsm.transition("start")
        if predicted_class == 0:
            self.fsm.transition("resume_navigation")
        elif predicted_class == 1:
            self.fsm.transition("obstacle_detected")
        elif predicted_class == 2:
            self.fsm.transition("red_light")
        elif predicted_class == 3:
            self.fsm.transition("planning_done")
        else:
            self.fsm.transition("stop")

        # Publish the new state
        self.state_pub.publish(self.fsm.state)
        rospy.loginfo(f"FSM transitioned to: {self.fsm.state} (class {predicted_class})")

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        node = FSMNode()
        node.run()
    except rospy.ROSInterruptException:
        pass
