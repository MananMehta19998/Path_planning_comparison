import rospy
from sensor_msgs.msg import Image

def camera_publisher():
    rospy.init_node('camera_input_node')
    pub = rospy.Publisher('/camera/image_raw', Image, queue_size=10)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        msg = Image()  # Mock message
        pub.publish(msg)
        rate.sleep()

if __name__ == '__main__':
    camera_publisher()