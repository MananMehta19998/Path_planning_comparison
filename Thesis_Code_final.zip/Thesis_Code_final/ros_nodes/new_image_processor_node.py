#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
from perception.canny_hough import detect_edges_and_lines
from perception.hu_moments import compute_hu_moments
from classification.svm_classifier import predict_svm

class ImageProcessor:
    def __init__(self):
        self.bridge = CvBridge()
        rospy.Subscriber("/camera/image_raw", Image, self.image_callback)
        self.pub = rospy.Publisher('/control_signal', String, queue_size=10)

    def image_callback(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            edges, lines = detect_edges_and_lines(cv_image)
            hu = compute_hu_moments(cv_image)
            label = predict_svm(hu)
            rospy.loginfo(f"Perception label: {label}")
            self.pub.publish(String(data=label))
        except Exception as e:
            rospy.logerr(f"Error processing image: {e}")

if __name__ == "__main__":
    rospy.init_node("image_processor_node", anonymous=True)
    processor = ImageProcessor()
    rospy.spin()